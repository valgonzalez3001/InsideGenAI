// src/screens/TokenizationScreen.jsx
import React, { useEffect, useState } from "react";

const TOKEN_COLORS = [
  "#ff6b6b",
  "#feca57",
  "#48dbfb",
  "#1dd1a1",
  "#5f27cd",
  "#ff9ff3",
  "#54a0ff",
];

export default function TokenizationScreen({ prompt, onNext }) {
  const [tokens, setTokens] = useState([]);      // todos los tokens
  const [visibleCount, setVisibleCount] = useState(0); // cuántos se muestran

  // 1) Cuando cambia el prompt, recalculamos tokens
  useEffect(() => {
    if (!prompt || !prompt.trim()) {
      setTokens([]);
      setVisibleCount(0);
      return;
    }

    const words = prompt.match(/\S+/g) || []; 
    console.log("Prompt recibido:", prompt);
    console.log("Tokens calculados:", words);

    setTokens(words);
    setVisibleCount(0); 
  }, [prompt]);

  useEffect(() => {
    if (tokens.length === 0) return;
    if (visibleCount >= tokens.length) return;

    const id = setInterval(() => {
      setVisibleCount((prev) => {
        if (prev >= tokens.length) return prev;
        return prev + 1;
      });
    }, 400);

    return () => clearInterval(id);
  }, [tokens, visibleCount]);

  const visibleTokens = tokens.slice(0, visibleCount);

  return (
    <div className="process-screen">
      <header className="process-header">
        <h2>Paso 1: Tokenización</h2>
        <p>
          El modelo no lee tu pregunta como una frase completa, sino que la
          rompe en piezas más pequeñas llamadas <strong>tokens</strong>.
        </p>
      </header>

      <main className="token-main">
        <div className="prompt-big">
          {visibleTokens.length === 0 && (
            <span className="prompt-fading">{prompt}</span>
          )}

          {visibleTokens.length > 0 && (
            <div className="tokens-line">
              {visibleTokens.map((token, idx) => (
                <span
                  key={`${token}-${idx}`}
                  className="token-chip"
                  style={{
                    borderColor: TOKEN_COLORS[idx % TOKEN_COLORS.length],
                    color: TOKEN_COLORS[idx % TOKEN_COLORS.length],
                  }}
                >
                  {token}
                </span>
              ))}
            </div>
          )}
        </div>

        <div className="explanation-box">
          <p>
            <strong>¿Qué está pasando?</strong>
          </p>
          <p>
            El texto se divide en unidades (tokens). Aquí simplificamos y
            consideramos cada palabra como un token. El LLM transforma estos
            tokens en números (vectores) que puede procesar matemáticamente.
          </p>
        </div>
      </main>

      <button className="next-arrow" onClick={onNext}>
        ➜
      </button>
    </div>
  );
}
